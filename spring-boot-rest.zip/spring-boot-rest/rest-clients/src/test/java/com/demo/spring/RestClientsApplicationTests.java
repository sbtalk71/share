package com.demo.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestClientsApplicationTests {

	@Test
	void contextLoads() {
	}

}
