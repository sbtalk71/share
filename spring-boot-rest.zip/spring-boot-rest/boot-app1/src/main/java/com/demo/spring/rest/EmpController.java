package com.demo.spring.rest;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.Emp;
import com.demo.spring.Message;
import com.demo.spring.repo.EmpRepository;

@RestController
public class EmpController {

	@Autowired
	private EmpRepository repo;

	@GetMapping(path = "/emp/find/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity getEmp(@PathVariable("id") int id) {
		Optional<Emp> o = repo.findById(id);
		// o.get().getEmpId();
		if (o.isPresent()) {
			return ResponseEntity.ok(o.get());
		} else {
			return ResponseEntity.ok("Employee Not Found");
		}
	}

	@PostMapping(path = "/emp/save", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> saveEmp(@RequestBody Emp e) {

		Message message = new Message();
		if (repo.existsById(e.getEmpId())) {
			message.setStatus("Employee already Exists");
			return ResponseEntity.ok(message);
		} else {
			repo.save(e);
			message.setStatus("Employee Saved Successfully");
			return ResponseEntity.ok(message);
		}

	}
	
	
	@PutMapping(path = "/emp/update", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Message> updateEmp(@RequestBody Emp e) {

			Message message = new Message();
			repo.save(e);
			message.setStatus("Employee updated Successfully");
			return ResponseEntity.ok(message);
		}
	
	@DeleteMapping(path="/emp/delete",produces = "application/json")
	public ResponseEntity<Message> deleteEmp(@RequestParam("id")int id) {
		Message message = new Message();
		if(repo.existsById(id)) {
			repo.deleteById(id);
			message.setStatus("Employee Deleted Successfully");
			return ResponseEntity.ok(message);
		}else {
			message.setStatus("Employee Not Found...");
			return ResponseEntity.ok(message);
		}
	}

}
